USE BagStoreDB;

-- List of all customers and their orders (QUERY 1)
SELECT c.customer_id, c.first_name, c.last_name, c.email, o.order_id, o.order_date, o.total_amount, o.delivery_status
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id;

-- Total orders (QUERY 2)
SELECT COUNT(order_id) AS total_orders
FROM Orders;

-- Prices on all bags in a descending order (QUERY 3)
SELECT bag_name, price
FROM Bags
ORDER BY price DESC;

-- Check the stock for all bags (QUERY 4)
SELECT bag_name, stock_quantity
FROM Bags;

-- Find the best selling bag (QUERY 5)
SELECT Bags.bag_name, SUM(Order_Bags.quantity) AS total_sold
FROM Order_Bags
JOIN Bags ON Order_Bags.bag_id = Bags.bag_id
GROUP BY Bags.bag_name
ORDER BY total_sold DESC
LIMIT 1;

-- Find my revenue (QUERY 6)
SELECT SUM(Bags.price * Order_Bags.quantity) AS total_revenue
FROM Order_Bags
JOIN Bags ON Order_Bags.bag_id = Bags.bag_id;

-- Check the stock after all orders (QUERY 7)
SELECT 
    b.bag_name,
    b.stock_quantity - IFNULL(SUM(ob.quantity), 0) AS remaining_stock
FROM Bags b
LEFT JOIN Order_Bags ob ON b.bag_id = ob.bag_id
GROUP BY b.bag_id, b.bag_name, b.stock_quantity;

-- Find me the bags with price over 100 (QUERY 8)
SELECT bag_name, price
FROM Bags
WHERE price > 100;

-- Find me how many bags were sold (QUERY 9)
SELECT SUM(quantity) AS total_bags_sold
FROM Order_Bags;

-- How many types of bags are available for each gender (QUERY 10)
SELECT gender, COUNT(*) AS total_bags
FROM Bags
GROUP BY gender;












